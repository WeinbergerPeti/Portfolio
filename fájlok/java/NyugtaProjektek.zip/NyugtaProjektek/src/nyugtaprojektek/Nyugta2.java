package nyugtaprojektek;

public class Nyugta2 {

    public static void main(String[] args) {
        String csillagok="******************";
        String vonal="------------------";
        String egyenlo="==================";
        String alsovonal="_______";
        String szokozok="   ";
        int tetel1=350;
        int tetel2=90;
        int tetel3=1320;
        double osszesen=tetel1+tetel2+tetel3;
        double kedvezmeny=osszesen*0.1;
        
        //System.out.println("******************");
        System.out.println(csillagok);
        System.out.println("     Nyugta 2");
        System.out.println(csillagok);
        System.out.printf("Tétel 1:    %d Ft\n",tetel1);
        System.out.printf("Tétel 2:     %d Ft\n",tetel2);
        System.out.printf("Tétel 3:   %d Ft\n",tetel3);
        System.out.println(egyenlo);
        System.out.printf("Összesen:  %1.0f Ft\n", osszesen);
        System.out.println(vonal);
        System.out.printf("Kedvezmény: %1.0f Ft\n", kedvezmeny);
        System.out.println("(10%)");
        System.out.println(egyenlo);
        System.out.printf("Fizetendő: %1.0f Ft\n",osszesen-kedvezmeny);
        System.out.println(vonal);
        System.out.println("");
        System.out.print(alsovonal);
        System.out.print(szokozok);
        System.out.println(alsovonal);
        System.out.print(" Dátum");
        System.out.print(szokozok);
        System.out.println("   Név");
        System.out.println(csillagok);
        System.out.println("        CÉG");
        System.out.println(csillagok);    
    }
    
}
