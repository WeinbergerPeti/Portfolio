package nyugtaprojektek;

public class Nyugta3 {

    public static void main(String[] args) {
        String csillagok="******************";
        String vonal="------------------";
        String egyenlo="==================";
        String alsovonal="_______";
        String szokozok="   ";
        int tetel1=350;
        int tetel2=90;
        int tetel3=1320;
        double osszesen=tetel1+tetel2+tetel3;
        double kedvezmeny=osszesen*0.1;
        final String HUF="Ft";
        final String EURO="\u20ac";
        
        //System.out.println("******************");
        System.out.println(csillagok);
        System.out.printf("%13s\n","Nyugta 3");
        System.out.println(csillagok);
        System.out.printf("%-10s %4d Ft\n","Tétel 1:",tetel1);
        System.out.printf("%-10s %4d Ft\n","Tétel 2:",tetel2);
        System.out.printf("%-10s %4d Ft\n","Tétel 3:",tetel3);
        System.out.println(egyenlo);
        System.out.printf("%-10s %1.0f Ft\n","Összesen:", osszesen);
        System.out.println(vonal);
        System.out.printf("%-10s %1.0f Ft\n","Kedvezmény:", kedvezmeny);
        System.out.println("(10%)");
        System.out.println(egyenlo);
        System.out.printf("%-10s %1.0f Ft\n","Fizetendő:",osszesen-kedvezmeny);
        System.out.println(vonal);
        System.out.println("");
        System.out.print(alsovonal);
        System.out.print(szokozok);
        System.out.println(alsovonal);
        System.out.print(" Dátum");
        System.out.print(szokozok);
        System.out.println("   Név");
        System.out.println(csillagok);
        System.out.println("        CÉG");
        System.out.println(csillagok);    
    }
    
}
