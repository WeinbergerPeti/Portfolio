package halallabirintus;

import java.util.Random;
import java.util.Scanner;

public class HalalLabirintus 
{

    public static void main(String[] args) 
    {
        Scanner sc= new Scanner(System.in);
        
        Random rnd = new Random();
        int dobas=0;
        
        int hosugyesseg=0;
        int hoseletero=0;
        int hosszerencse=0;
        
        hosugyesseg = dobas1ciklus(rnd, hosugyesseg);
        
        
        hoseletero = dobas2ciklus(rnd, hoseletero);
        hoseletero+=12;
        
        hosszerencse = dobas1ciklus(rnd, hosszerencse);
        
        System.out.println("A kezdeti pontjaid: ");
        System.out.printf("Az ügyesség pontod: %d\n",hosugyesseg);
        System.out.printf("Az életerő pontod: %d\n",hoseletero);
        System.out.printf("Az szerencse pontod: %d\n",hosszerencse);
        
        
//        System.out.println("\nAz utad során szembe találkozol egy gyilkos lénnyel!");        
//        int lenyugyesseg = 0;
//        int lenytamadoero = 0;
//        
//        lenytamadoero = dobas2ciklus(rnd, lenytamadoero);
//        lenyugyesseg += lenytamadoero;
//        System.out.printf("A lény támadóerő pontja: %d\n",lenyugyesseg);
//
//        
//        System.out.println("\n ");
//        int hostamadoero=0;
//        hostamadoero=dobas2ciklus(rnd, hostamadoero);
//        hosugyesseg+=hostamadoero;
//        
//        System.out.println(hostamadoero);
//        System.out.printf("A hős támadóerő pontja: %d\n",hosugyesseg);
        
        
        
        System.out.println("\n\n\nOldalak rész:");
        
        System.out.println("Egy versenyre nevezel, aminek a lényege, hogy át kell kelni a halállabirintuson.\nA labirintusban tárgyakat találhatsz és szörnyekkel kell harcoljál.");
        
        String oldal_1="\nMiután öt percet haladtál lassan az alagútban, egy kőasztalhoz érsz, amely a bal oldali fal mellett áll. Hat doboz van rajta, egyikükre a te neved festették.\nHa kiakarod nyitni a dobozt, lapozz a 270-re. Ha inkább tovább haladsz észak felé, lapozz a 66-ra.";
        String oldal_56="\nLátod, hogy az akadály egy széles, barna, sziklaszerű tárgy. Megérinted, és meglepve tapasztalod, hogy lágy, szivacsszerű.\nHa át szeretnél mászni rajta, lapozz a 373-ra. Ha ketté akarod vágni a kardoddal, lapozz a 215-re.";
        String oldal_66="\nNéhány perc gyaloglás után egy elágazáshoz érsz az alagútban. Egy, a falra festett fehér nyíl nyugatfelé mutat.\nA földön nedves lábnyomok jelzik, merre haladtak az előtted járók.\nNehéz biztosan megmondani, de úgy tűnik, hogy három közülük a nyíl irányába halad, míg egyikük úgy döntött, hogy keletnek megy.\nHa nyugat felé kívánsz menni, lapozz a 293-ra. Ha keletnek, lapozz a 56-re.";
        
        String oldal_137 ="\nAhogy végigmész az alagúton, csodálkozva látod, hogy egy jókora vasharang csüng alá a boltozatról.";
        String oldal_215="\nKardod könnyedén áthatol a spóragolyó vékonykülső burkán. Sűrű barna spórafelhő csap ki a golyóból, és körülvesz.\nNémelyik spóra a bőrödhöz tapad, és rettenetes viszketést okoz. Nagy daganatok nőnek az arcodon és karodon, és a bőröd mintha égne.\n2 ÉLETERŐ pontot veszítesz. Vadul vakarózva átléped a leeresztett golyót, és keletnek veszed az utad.";
        String oldal_270="\nA doboz teteje könnyedén nyílik. Benne két aranypénzt találsz, és egy üzenetet, amely egy kis pergamenen neked szól.\nElőbb zsebre vágod az aranyakat, aztán elolvasod az üzenetet: - „Jól tetted. Legalább volt annyi eszed, hogy megállj és elfogadd az ajándékot.\nMost azt tanácsolom neked, hogy keress és használj különféle tárgyakat, ha sikerrel akarsz áthaladni Halállabirintusomon.” Azaláírás Szukumvit.\nMegjegyzed a tanácsot, apródarabokra téped a pergament, és tovább mészészak felé. Lapozz a 66-ra.";
        String oldal_293="\nA három pár nedves lábnyomot követve az alagútnyugati elágazásában hamarosan egy újabb el-ágazáshoz érsz.\nHa továbbmész nyugat felé a lábnyomokat követve, lapozz a 137-re. Ha inkább észak felé mész a harmadik pár lábnyom után, lapozz a 387-re.";
        String oldal_373="\nFölmászol a lágy sziklára, attól tartasz, hogy bár-melyik pillanatban elnyelhet.\nNehéz átvergődni rajta, mert puha anyagában alig tudod a lábadat emelni, de végül átvergődsz rajta. Megkönnyebbülten érsz újra szilárd talajra, és fordulsz kelet felé.";
        String oldal_387="\nHallod, hogy elölről súlyos lépések közelednek.\nEgy széles, állatbőrökbe öltözött, kőbaltás, primitívlény lép elő. Ahogy meglát, morog, a földre köp, majd a kőbaltát felemelve közeledik, és mindennek kinéz, csak barátságosnak nem.\nElőhúzod kardodat, és felkészülsz, hogy megküzdj a Barlangi Emberrel.";
        
        int barlangiEmberUgyesseg=7;
        int barlangiEmberEletero=7;
        
        System.out.println(oldal_1);
        System.out.print("\nAdd meg a választott oldalt: ");
        int oldalszam=sc.nextInt();
        
        if(oldalszam==66)
        {
            System.out.println(oldal_66);
            oldalvalasztas(oldalszam);
            oldalszam=sc.nextInt();
            if(oldalszam==293)
            {
                System.out.println(oldal_293);
                oldalvalasztas(oldalszam);
                oldalszam=sc.nextInt();
                if(oldalszam==137)
                {
                    System.out.println(oldal_137);
                }
                else if(oldalszam==387)
                {
                    System.out.println(oldal_387);
                    for (int i = 0; i < barlangiEmberUgyesseg; i++) 
                    {
                        if(hosugyesseg>barlangiEmberUgyesseg)
                        {
                            barlangiEmberEletero -= 2;
                        }
                    }
                    
                }
                else
                {
                    System.out.println("Rossz oldalszámot adtál meg próbáld újra!: ");
                    oldalszam=sc.nextInt();
                }
            }
            else if(oldalszam==56)
            {
                System.out.println(oldal_56);
                oldalvalasztas(oldalszam);
                oldalszam=sc.nextInt();
                if(oldalszam==373)
                {
                    System.out.println(oldal_373);
                }
                else if(oldalszam==215)
                {
                    System.out.println(oldal_215);
                }
                else
                {
                    System.out.println("Rossz oldalszámot adtál meg próbáld újra!: ");
                    oldalszam=sc.nextInt();
                }
            }
            else
            {
                System.out.println("Rossz oldalszámot adtál meg próbáld újra!: ");
                oldalszam=sc.nextInt();
            }
            
               
        }
        else if(oldalszam==270)
        {
            System.out.println(oldal_270);
            System.out.println(oldal_66);
            oldalvalasztas(oldalszam);
            oldalszam=sc.nextInt();
            if(oldalszam==293)
            {
                System.out.println(oldal_293);
                oldalvalasztas(oldalszam);
                oldalszam=sc.nextInt();
                if(oldalszam==137)
                {
                    System.out.println(oldal_137);
                }
                else if(oldalszam==387)
                {
                    System.out.println(oldal_387);
                }
                else
                {
                    System.out.println("Rossz oldalszámot adtál meg próbáld újra!: ");
                    oldalszam=sc.nextInt();
                }
            }
            else if(oldalszam==56)
            {
                System.out.println(oldal_56);
                oldalvalasztas(oldalszam);
                oldalszam=sc.nextInt();
                if(oldalszam==373)
                {
                    System.out.println(oldal_373);
                }
                else if(oldalszam==215)
                {
                    System.out.println(oldal_215);
                }
                else
                {
                    System.out.println("Rossz oldalszámot adtál meg próbáld újra!: ");
                    oldalszam=sc.nextInt();
                }
            }
            else
            {
                System.out.println("Rossz oldalszámot adtál meg próbáld újra!: ");
                oldalszam=sc.nextInt();
            }
        }
        
        
        
    }

    private static void oldalvalasztas(int oldalszam) {
        System.out.print("\nVálassz olalt: ");
    }

    private static int dobas1ciklus(Random rnd, int szam) {
        int dobas;
        for (int i = 0; i < 1; i++)
        {
            dobas=rnd.nextInt(6)+1;
            szam+=dobas+6;
        }
        return szam;
    }

    private static int dobas2ciklus(Random rnd, int szam) {
        int dobas;
        for (int i = 0; i < 2; i++)
        {
            dobas=rnd.nextInt(6)+1;
            szam+=dobas;
        }
        return szam;
    }
    
    
}
