package formazottkiiras;

public class FormazottKiiras {

    public static void main(String[] args) 
    {
        int egesz= 7;
        String szoveg="szöveg";
        double valos=3.1415;
        System.out.printf("egész: %d | string %s | tört: %f\n",egesz,szoveg,valos);
        System.out.printf("2 tizedessel: %.2f\n", valos);
        System.out.printf("3 tizedessel: %.3f\n", valos);
        
        System.out.printf(">szöveg<\n");
        System.out.printf(">%10s<\n","jobb");
        System.out.printf(">%-10s<\n","bal");
        
        System.out.println("\nEgészek listája: ");
        int e2=17;
        int e3=234;
        int e4=-5;
        System.out.printf("%3d\n", egesz);
        System.out.printf("%3d\n", e2);
        System.out.printf("%3d\n", e3);
        System.out.printf("%3d\n", e4);
        
        System.out.println("\nValósak listája: ");
        double tort=1.0/3;
        e2=1;
        e3=3;
        tort=(double)e2/e3;
        double d2 = 123.58;
        
        System.out.printf("%8.4f\n",valos);
        System.out.printf("%8.4f\n",tort);
        System.out.printf("%8.4f\n",d2);

        String nev= "Péter";
        final int MAX_DB=4;
        int db=4;
        double atlag=4.52;
        System.out.printf("%s %d jegyének átlaga: %2.f (max: %d)\n", nev, db, atlag, MAX_DB);
        
        
        nev="Pál";
        //MAX_DB=24;
        db=3;
        atlag=3.85;
        System.out.printf("%s %d jegyének átlaga: %2.f (max: %d)\n", nev, db, atlag, MAX_DB);
        
        
        
        
    }
    
}
