# logaikai bevezetés



def logikai():
    a = None
    print(bool(a))


def kiiratasok():
    sz = "Ez egy mondat."
    # sz2 = "Ez"
    # szam = 7
    print("Első karakter: ", sz[0])
    print("Negyedik karakter: ", sz[3])
    print("Kisebb-nagyobb: ", sz[-1])
    print("5-nél kisebb 2-nél nagyobb:", sz[2:5])
    print("3. utáni karakterek lesznek: ", sz[3:])
    # print("Negyedik karakter: ", sz[:5])
    # print("Negyedik karakter: ", sz[0:-1:2])
    # print("Negyedik karakter: ", sz[::-1])
    # print("Negyedik karakter: ", sz[::-2])
    # print("Negyedik karakter: ", sz+str(sz))
    # print("Negyedik karakter: ", sz*3)


# 1 feladat megoldása
def karakterek_szama():
    szo = input("Kérek egy szöveget: ")
    print("A szöveg hossza: ", len(szo))


# 2 feladat
def masodik_feladat():
    szo2 = input("Kérek egy szöveget: ")
    print("A szöveg hossza: ", len(szo2))
    char_num = int(input("Melyik karakterre kiváncsi: "))
    if (char_num <= len(szo2)) and (char_num > 0):
        print(szo2[char_num-1])
    else:
        print("Ilyen karakter nincs")


#3. feladat
def harmadik_feladat():
    palnidrom=input("Kérek egy palindrom szót: ")


#4. feladat
def negyedik_feladat():
    mondat=input("Kérek egy mondatot: ")

    if mondat[-1]==',':
        print("A mondat végén vessző van.")
    elif mondat[-1]=='!':
        print("A mondat végén !-jel van.")
    elif mondat[-1] == '.':
        print("A mondat végén pont van.")
    elif mondat[-1] == '?':
        print("A mondat végén ?-jel van.")
    else:
        print("Betű van a mondat végén.")


#5. feladat
def otodik_feladat():

    mondat=input("Adj meg egy mondatot: ")
    betu='h'

    if betu in mondat:
        print("Van benne h betű")
    else:
        print("Nincs benne h betű")

#6. feladat
def hatodik_feladat():
    elso_szo=input("Adj meg egy szót:")
    masodik_szo=input("Adj meg egy szót:")
    harmadik_szo=input("Adj meg egy szót:")
    elso_hossza=len(elso_szo)
    masodik_hossza=len(masodik_szo)
    harmadik_hossza=len(harmadik_szo)



    if elso_hossza>masodik_hossza and elso_hossza>harmadik_hossza:
        print("Az első szó a leghosszabb:",elso_szo)
    elif masodik_hossza>elso_hossza and masodik_hossza>harmadik_hossza:
        print("A második szó a leghosszabb:",masodik_szo)
    elif harmadik_hossza>elso_hossza and harmadik_hossza>masodik_hossza:
        print("A harmadik szó a leghosszabb:",harmadik_szo)

#7. feladat

def hetedik_feladat():
    mondat= input("Kérek egy mondatot: ")
    nagy_kezdobetu=mondat.capitalize()

    if mondat[-1]=='.':
        print(nagy_kezdobetu)
    else:
        print(nagy_kezdobetu+".")


#8. feladat
#def nyolcadik_feladat():

