import szoveg

# szoveg.logikai()
# szoveg.kiiratasok()
# szoveg.karakterek_szama()
# szoveg.masodik_feladat()

#szoveg.negyedik_feladat()
#szoveg.otodik_feladat()
#szoveg.hatodik_feladat()
#szoveg.hetedik_feladat()