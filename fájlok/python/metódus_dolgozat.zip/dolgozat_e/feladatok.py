
def feladat1():
    benev = input("Kérek egy nevet: ")
    beszam = int(input("Kérek egy óraszámot: "))
    tantargy = "hálózat"

    print(f"{benev} {beszam}. órája {tantargy}.")


def feladat2():

    a = float(input("Kérem a háromszög A oldalának az értékét: "))
    b = float(input("Kérem a háromszög B oldalának az értékét: "))
    c = float(input("Kérem a háromszög C oldalának az értékét: "))

    if a > 0 and b > 0 and c > 0:
        print("Lehet háromszöget szerkeszteni a megadott számokkal.")
    else:
        print("Nem megfelelő értéket adott meg, nem szerkezthető háromszög!")


def feladat3():
    a = int(input("Kérem az A értékét: "))
    b = int(input("Kérem az B értékét: "))
    c = int(input("Kérem az C értékét: "))

    diszkriminans = b*b-(4*a*c)

    if diszkriminans >= 0:
        print(f"Helyes számokat adott meg, a diszkrimináns eredménye: {diszkriminans}")
    else:
        print("Nem megfelelő számokat adott meg:")


def feladat4():
    beszam = int(input("Kérek egy [1200, 1920] intervallumban lévő egész számot: "))

    masodik_szamjegy = (beszam//100) % 10

    if (beszam >= 1200) and beszam <= 1920:

        print(f"A szám második számjegye: {masodik_szamjegy}")
    else:
        print("Rossz számot adott meg!")


def feladat5():

    beoraszam = int(input("Adjon meg egy tanóraszámot: "))

    feltetel = (beoraszam >= 1) and beoraszam <= 9
    if feltetel and beoraszam <= 2:
        print("A teljesítményük 90%-os.")
    elif feltetel and beoraszam <= 5:
        print("A teljesítményük 60%-os.")
    elif feltetel and beoraszam <= 7:
        print("A teljesítményük 70%-os.")
    elif feltetel and beoraszam <= 9:
        print("A teljesítményük 50%-os.")
    else:
        print("Ez már tényleg túlzás.")


def feladat6():

    print("Marci")

    oraneve = input("Kérek egy óra nevét: ")
    benap = input("Kérek egy nap nevét (pl.: hétfő): ")

    if benap == "hétfő" and oraneve:
        print("Hétfőn alszik az összes órán.")
    elif benap == "kedd" and oraneve == "hálózat":
        print("Kedden csak hálózat órán figyel.")
    elif benap == "kedd" and oraneve != "hálózat":
        print("Kedden nem figyel más órára csak a hálózatra.")
    elif benap == "szerda" and oraneve == "programozás":
        print("Programozás órán mindig dolgozik, de csak szerdán")
    elif benap == "csütörtök" and oraneve:
        print("Csütörtökön minden órán figyel, mert jó kedve van (aznap szokott moziba menni)")
    elif benap == "péntek" and oraneve:
        print("Pénteken a hétvégéről ábrándozik, így csak félig figyel minden aznapi órán")
    else:
        print("A többi egyéb óráról semmit nem tudunk.")
