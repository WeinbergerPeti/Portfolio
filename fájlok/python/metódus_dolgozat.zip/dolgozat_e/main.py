import feladatok

feladatok.feladat1()
feladatok.feladat2()
feladatok.feladat3()
feladatok.feladat4()
feladatok.feladat5()
feladatok.feladat6()
