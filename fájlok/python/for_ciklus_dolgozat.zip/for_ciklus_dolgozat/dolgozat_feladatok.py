def fel1_b():
    for i in range(-99, 100):
        if i % 5 == 0:
            print(i, end=" ")


def fel2_a():
    szamlalo = 0
    for i in range(70, -8, -1):
        szamlalo += 1
        if szamlalo % 7 == 0:
            print(i)
        else:
            print(i, end=" ")


def fel3_b():
    db = 0
    for i in range(4):
        szo = input("Kérek egy szót: ")
        if len(szo) == 6:
            db += 1
    print("A 6 hosszú szavak száma:", db)


def fel3_a():
    # az első szó hosszát tároljuk, és ehhez viszonyítunk
    maximum = input("Kérek egy szót: ")
    for i in range(5):
        szo = input("Kérek egy szót: ")
        if len(szo) > len(maximum):
            maximum = szo
    print("A leghosszabb szó:", maximum)
