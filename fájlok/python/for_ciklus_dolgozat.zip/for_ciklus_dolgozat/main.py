import feladatok

#feladatok.A_feladat1()
#feladatok.A_feladat2()
#feladatok.A_feladat3()

#feladatok.B_feladat1()
#feladatok.B_feladat2()
#feladatok.B_feladat3()
feladatok.gyakorlas()