


def A_feladat1():

    for i in range(100,1000+1):
        if i%9==0:
            print(i,end=" ")


def A_feladat2():

    szamlalo=0

    for i in range(70,-8,-1):
        szamlalo+=1
        if szamlalo%7==0:
            print(i)
        else:
            print(i,end=" ")

def A_feladat3():

    maximum=input("Kérek egy szót: ")
    for i in range(5):
        szo=input("Kérek egy szót: ")
        if len(szo)>len(maximum):
            maximum=szo
    print(maximum)

def B_feladat1():

    for i in range(-99,99+1):
        if i%5==0:
            print(i,end=" ")

def B_feladat2():

    szamlalo=0
    for i in range(500,-30,-1):
        szamlalo+=1
        if szamlalo%4==0:
            print(i)
        else:
            print(i,end=" ")

def B_feladat3():

    db=0
    for i in range(4):
        szo=input("Kérek egy szót: ")
        if len(szo)==6:
            db+=1
    print(f"A 6 karakterből álló szavak száma: {db}")

def gyakorlas():

    # maxi=input("Kérek egy szót: ")
    # for i in range(5):
    #     szo=input("Kérek egy szót:")
    #     if len(szo)>len(maxi):
    #         maxi=szo
    # print(maxi)

    szamlalo=0
    for i in range(70,-8,-1):
        szamlalo+=1
        if szamlalo%7==0:
            print(i)
        else:
            print(i,end=" ")
