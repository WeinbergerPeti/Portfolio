import math

def faktorialis():
    szam = int(input("Kérek egy számot: "))
    eredmeny = 1
    if szam < 0:
        print("Nem értelmezhető")
    else:
        for i in range(1, szam + 1):
            eredmeny *= i  # eredmeny = eredmeny * i
        print("A", szam, "faktoriális eredménye:", eredmeny)


def feladat2():
    for i in range(151):
        if i % 2 == 0:
            print(i, end=" ")


def feladat2_mashogy():
    for i in range(0, 151, 2):
        print(i, end=" ")


def feladat3():  # refaktorizálni egy forciklussal megcsinálni

    szam1 = int(input("Kérek egy egész számot:"))
    szam2 = int(input("Kérek egy egész számot:"))
    db = 0
    if szam1 < szam2:
        for i in range(szam1, szam2 + 1):
            if i % 2 == 1:
                db += 1
        print("A páratlan számok drabja: ", db)
    else:
        for i in range(szam2, szam1 + 1):
            if i % 2 == 1:
                db += 1
        print("A páratlan számok drabja: ", db)


def feladat4():
    db = 0
    for i in range(10):
        szam = int(input("Kérek egy számot: "))
        db += szam % 3 == 0
    print(db)


def feladat5():
    osszeg = 0
    for i in range(5):
        szam = int(input("Kérem a(z) "+str(i + 1)+" . számot: "))
        osszeg += szam
    print(osszeg)

def feladat6():
    szoveg=""
    for i in range(5):
        szo=input("Kérek egy szót: ")
        szoveg+=szo+" "
    print(szoveg)

def feladat7():
    osszeg=0
    for i in range(10):
        szam = int(input("Kérek egy számot: "))
        if szam<0:
            osszeg+=szam
    print("Negatív számok: ", osszeg)

def feladat8():
    max=int(input("Kérek egy számot: "))

    for i in range(4):
        szam = int(input("Kérek egy számot: "))
        if max<szam:
            max=szam
            print(max)
        else:
            print()

    print(max)

def feladat9():
    min=int(input("Kérek egy számot: "))

    for i in range(4):
        szam = int(input("Kérek egy számot: "))
        if min>szam:
            min=szam

    print(min)

def feladat12():

    for i in range(0,151):
        gyok = math.sqrt(i)
        if int(gyok)==gyok:
            print("Négyzetszám: ", i)

"""def feladat13():

    szam=int(input("Szám: "))
    math."""

