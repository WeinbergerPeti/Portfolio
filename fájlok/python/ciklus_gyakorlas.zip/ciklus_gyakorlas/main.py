import metodus

#metodus.faktorialis()
#metodus.feladat5()
#metodus.feladat6()
#metodus.feladat7()
#metodus.feladat8()
#metodus.feladat9()
metodus.feladat12()