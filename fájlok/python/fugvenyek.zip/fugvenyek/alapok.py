import random

def fuggveny_mit_csinal(bejovo):
    return bejovo+2

def lista_veletlen(elem_szam=10, also=1, felso=25):
    lista=[]
    for i in range(elem_szam):
        lista.append(random.randint(also,felso))
    return lista #[0], lista[1]

def megszamlalas_tetel(lista = None):
    db=0
    #lista=lista_veletlen()
    print(lista)
    for i in range(len(lista)):
        if lista[i]%2==0:
            db+=1
    return db

def lista_logikai():
    lista=[]
    for i in range(100):
        if random.randint(1,2)==1:
            fej= True
        else:
            fej=False
        lista.append(fej)
    return lista

def kiir(lista=None):
    szoveg=""
    for i in range(len(lista)):
        szoveg+=lista[i]+"*"
    szoveg=szoveg[:-1] #utolsó csillag levágása
    return szoveg

def kifejezes(x=2):
    return x**2+3*x

def atlag(lista=None):
    osszeg=0
    for i in range(len(lista)):
        osszeg+= lista[i]
    return osszeg/len(lista)