import alapok
import ellenorzott_bekeres

#szam_novelt=alapok.fuggveny_mit_csinal(6)
"""print(szam_novelt)
print(alapok.lista_veletlen(10,1,25))"""
"""print(f"A listában lévő páros számok: {alapok.megszamlalas_tetel(alapok.lista_veletlen())}")"""
#print(alapok.kiir(alapok.lista_veletlen()))
#print(alapok.kiir(alapok.lista_logikai()))
#print(f"A bemenő érték alapján a kifejezés eredménye: {alapok.kifejezes(2)}")
"""lista=alapok.lista_veletlen()
print(f"Pontos kiíratás: {alapok.atlag(lista):.4f}")
print(f"Kevésbé pontos kiíratás: {alapok.atlag(lista):.0f}")"""

#ellenorzott_bekeres.kisseb()
#ellenorzott_bekeres.paros_pozitiv()
print(ellenorzott_bekeres.paros_pozitiv_lista_feltoltese())