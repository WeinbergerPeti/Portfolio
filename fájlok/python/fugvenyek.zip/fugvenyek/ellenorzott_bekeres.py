def kisseb():
    szam=float(input("Kérek egy negatív valós számot: "))
    while not(szam<0):
        szam = float(input("Kérek újra egy negatív valós számot: "))
    return szam

def paros_pozitiv():
    szam=int(input("Kérek egy páros és pozitív valós számot: "))
    while not (szam>0 and szam%2==0):
        szam = int(input("Kérek újra páros és pozitív valós számot: "))
    return szam

def paros_pozitiv_lista_feltoltese():
    lista=[]
    for i in range(3):
        ertek=paros_pozitiv()
        lista.append(ertek)
    return lista
